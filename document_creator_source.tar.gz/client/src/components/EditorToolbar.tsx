import { Button } from "@/components/ui/button";
import {
  Bold,
  Italic,
  Underline,
  AlignLeft,
  AlignCenter,
  AlignRight,
  List,
  ListOrdered,
  Link,
  Image,
  Table,
  Save,
  Download,
  Share2,
  Undo2,
  Redo2,
  FileText,
  Menu,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Separator } from "@/components/ui/separator";

interface EditorToolbarProps {
  onBold?: () => void;
  onItalic?: () => void;
  onUnderline?: () => void;
  onAlignLeft?: () => void;
  onAlignCenter?: () => void;
  onAlignRight?: () => void;
  onBulletList?: () => void;
  onNumberedList?: () => void;
  onLink?: () => void;
  onImage?: () => void;
  onTable?: () => void;
  onSave?: () => void;
  onUndo?: () => void;
  onRedo?: () => void;
  onNewDocument?: () => void;
  onOpenDocument?: () => void;
  onDownload?: () => void;
  onShare?: () => void;
}

export default function EditorToolbar({
  onBold,
  onItalic,
  onUnderline,
  onAlignLeft,
  onAlignCenter,
  onAlignRight,
  onBulletList,
  onNumberedList,
  onLink,
  onImage,
  onTable,
  onSave,
  onUndo,
  onRedo,
  onNewDocument,
  onOpenDocument,
  onDownload,
  onShare,
}: EditorToolbarProps) {
  return (
    <div className="flex flex-col border-b border-border bg-background">
      {/* Menu Bar */}
      <div className="flex items-center h-12 px-4 border-b border-border bg-secondary/30">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 font-semibold text-foreground hover:bg-secondary"
            >
              <FileText className="w-4 h-4" />
              Ficheiro
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={onNewDocument}>
              Novo Documento
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onOpenDocument}>
              Abrir
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onSave}>Guardar</DropdownMenuItem>
            <DropdownMenuItem onClick={onDownload}>
              Transferir como PDF
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 font-semibold text-foreground hover:bg-secondary"
            >
              Editar
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={onUndo}>Desfazer</DropdownMenuItem>
            <DropdownMenuItem onClick={onRedo}>Refazer</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="gap-2 font-semibold text-foreground hover:bg-secondary"
            >
              Inserir
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start">
            <DropdownMenuItem onClick={onLink}>Ligação</DropdownMenuItem>
            <DropdownMenuItem onClick={onImage}>Imagem</DropdownMenuItem>
            <DropdownMenuItem onClick={onTable}>Tabela</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={onShare}
            className="gap-2 text-foreground hover:bg-secondary"
          >
            <Share2 className="w-4 h-4" />
            Partilhar
          </Button>
        </div>
      </div>

      {/* Formatting Toolbar */}
      <div className="flex items-center h-14 px-2 sm:px-4 gap-1 overflow-x-auto bg-background">
        {/* Undo/Redo */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onUndo}
          title="Desfazer"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary hidden sm:flex"
        >
          <Undo2 className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onRedo}
          title="Refazer"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Redo2 className="w-4 h-4" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Text Formatting */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onBold}
          title="Negrito (Ctrl+B)"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Bold className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onItalic}
          title="Itálico (Ctrl+I)"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Italic className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onUnderline}
          title="Sublinhado (Ctrl+U)"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Underline className="w-4 h-4" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Alignment */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onAlignLeft}
          title="Alinhar à esquerda"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <AlignLeft className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onAlignCenter}
          title="Alinhar ao centro"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <AlignCenter className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onAlignRight}
          title="Alinhar à direita"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <AlignRight className="w-4 h-4" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Lists */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onBulletList}
          title="Lista com marcas"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <List className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onNumberedList}
          title="Lista numerada"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <ListOrdered className="w-4 h-4" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Insert */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onLink}
          title="Inserir ligação"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Link className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onImage}
          title="Inserir imagem"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Image className="w-4 h-4" />
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={onTable}
          title="Inserir tabela"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Table className="w-4 h-4" />
        </Button>

        <Separator orientation="vertical" className="h-6 mx-1" />

        {/* Save */}
        <Button
          variant="ghost"
          size="sm"
          onClick={onSave}
          title="Guardar (Ctrl+S)"
          className="gap-2 text-muted-foreground hover:text-foreground hover:bg-secondary"
        >
          <Save className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}
