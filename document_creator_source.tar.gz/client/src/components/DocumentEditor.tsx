import { useRef, useEffect, useState } from "react";

interface DocumentEditorProps {
  content?: string;
  onChange?: (content: string) => void;
  placeholder?: string;
}

export default function DocumentEditor({
  content = "",
  onChange,
  placeholder = "Comece a escrever o seu documento...",
}: DocumentEditorProps) {
  const editorRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isFocused, setIsFocused] = useState(false);
  const [zoom, setZoom] = useState(100);

  useEffect(() => {
    if (editorRef.current && content !== editorRef.current.innerHTML) {
      editorRef.current.innerHTML = content;
    }
  }, [content]);

  // Ajustar zoom para responsividade
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.clientWidth;
        // Papel A4: 794px de largura + 40px padding
        const pageWidth = 834;
        const newZoom = Math.max(50, Math.min(100, (containerWidth / pageWidth) * 100));
        setZoom(newZoom);
      }
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const handleInput = () => {
    if (editorRef.current) {
      onChange?.(editorRef.current.innerHTML);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLDivElement>) => {
    // Handle Tab key for indentation
    if (e.key === "Tab") {
      e.preventDefault();
      document.execCommand("insertHTML", false, "&nbsp;&nbsp;&nbsp;&nbsp;");
    }

    // Ctrl+B for Bold
    if (e.ctrlKey && e.key === "b") {
      e.preventDefault();
      document.execCommand("bold");
    }

    // Ctrl+I for Italic
    if (e.ctrlKey && e.key === "i") {
      e.preventDefault();
      document.execCommand("italic");
    }

    // Ctrl+U for Underline
    if (e.ctrlKey && e.key === "u") {
      e.preventDefault();
      document.execCommand("underline");
    }
  };

  return (
    <div
      ref={containerRef}
      className="flex-1 flex flex-col overflow-hidden bg-muted/20"
    >
      {/* Zoom Controls */}
      <div className="h-10 px-4 bg-secondary/30 border-b border-border flex items-center justify-between text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <span>Zoom:</span>
          <input
            type="range"
            min="50"
            max="200"
            value={zoom}
            onChange={(e) => setZoom(Number(e.target.value))}
            className="w-24"
          />
          <span>{Math.round(zoom)}%</span>
        </div>
      </div>

      {/* Page Container */}
      <div className="flex-1 overflow-auto p-5 flex justify-center">
        <div
          style={{
            transform: `scale(${zoom / 100})`,
            transformOrigin: "top center",
            transition: "transform 0.2s ease",
          }}
        >
          {/* Document Page - A4 Size: 794px × 1123px */}
          <div
            className="bg-white rounded-sm shadow-2xl"
            style={{
              width: "794px",
              minHeight: "1123px",
              padding: "94px",
              boxShadow:
                "0 1px 6px rgba(0,0,0,.2), 0 4px 20px rgba(0,0,0,.12)",
            }}
          >
            <div
              ref={editorRef}
              contentEditable
              suppressContentEditableWarning
              onInput={handleInput}
              onKeyDown={handleKeyDown}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              className={`
                w-full min-h-full focus:outline-none
                text-foreground text-base leading-relaxed
                font-serif
                [&_h1]:text-2xl [&_h1]:font-bold [&_h1]:mb-4 [&_h1]:font-sans
                [&_h2]:text-xl [&_h2]:font-semibold [&_h2]:mb-3 [&_h2]:font-sans
                [&_h3]:text-lg [&_h3]:font-semibold [&_h3]:mb-2 [&_h3]:font-sans
                [&_p]:mb-4 [&_p]:text-base
                [&_ul]:list-disc [&_ul]:ml-6 [&_ul]:mb-4
                [&_ol]:list-decimal [&_ol]:ml-6 [&_ol]:mb-4
                [&_li]:mb-2
                [&_a]:text-primary [&_a]:underline hover:[&_a]:text-primary/80
                [&_blockquote]:border-l-4 [&_blockquote]:border-primary [&_blockquote]:pl-4 [&_blockquote]:italic [&_blockquote]:mb-4 [&_blockquote]:text-gray-600
                [&_code]:bg-secondary [&_code]:px-2 [&_code]:py-1 [&_code]:rounded [&_code]:font-mono [&_code]:text-sm
                [&_pre]:bg-secondary [&_pre]:p-4 [&_pre]:rounded [&_pre]:overflow-x-auto [&_pre]:mb-4 [&_pre]:font-mono
                [&_table]:border-collapse [&_table]:w-full [&_table]:mb-4
                [&_th]:border [&_th]:border-border [&_th]:p-2 [&_th]:bg-secondary [&_th]:text-left [&_th]:font-semibold
                [&_td]:border [&_td]:border-border [&_td]:p-2
                [&_img]:max-w-full [&_img]:h-auto [&_img]:rounded [&_img]:my-4
              `}
              data-placeholder={placeholder}
            />
          </div>
        </div>
      </div>

      {/* Status Bar */}
      <div className="h-8 px-4 bg-secondary/30 border-t border-border flex items-center text-xs text-muted-foreground gap-4">
        <span>Pronto</span>
        <span>•</span>
        <span>Página 1</span>
        <span>•</span>
        <span>{Math.round(zoom)}% zoom</span>
      </div>
    </div>
  );
}
